export const navigate = (route: string) => {
  window.location.href = route;
};
