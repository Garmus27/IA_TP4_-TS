export type Rol = "client" | "admin";
